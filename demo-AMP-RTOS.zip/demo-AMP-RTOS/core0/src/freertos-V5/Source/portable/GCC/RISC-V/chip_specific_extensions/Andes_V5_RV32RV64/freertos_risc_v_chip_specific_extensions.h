/*
 * FreeRTOS Kernel V10.5.1
 * Copyright (C) 2021 Amazon.com, Inc. or its affiliates.  All Rights Reserved.
 *
 * SPDX-License-Identifier: MIT
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of
 * this software and associated documentation files (the "Software"), to deal in
 * the Software without restriction, including without limitation the rights to
 * use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
 * the Software, and to permit persons to whom the Software is furnished to do so,
 * subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
 * FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
 * IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * https://www.FreeRTOS.org
 * https://github.com/FreeRTOS
 *
 */

/*
 * The FreeRTOS kernel's RISC-V port is split between the the code that is
 * common across all currently supported RISC-V chips (implementations of the
 * RISC-V ISA), and code that tailors the port to a specific RISC-V chip:
 *
 * + FreeRTOS\Source\portable\GCC\RISC-V\portASM.S contains the code that
 *   is common to all currently supported RISC-V chips.  There is only one
 *   portASM.S file because the same file is built for all RISC-V target chips.
 *
 * + Header files called freertos_risc_v_chip_specific_extensions.h contain the
 *   code that tailors the FreeRTOS kernel's RISC-V port to a specific RISC-V
 *   chip.  There are multiple freertos_risc_v_chip_specific_extensions.h files
 *   as there are multiple RISC-V chip implementations.
 *
 * !!!NOTE!!!
 * TAKE CARE TO INCLUDE THE CORRECT freertos_risc_v_chip_specific_extensions.h
 * HEADER FILE FOR THE CHIP IN USE.  This is done using the assembler's (not the
 * compiler's!) include path.  For example, if the chip in use includes a core
 * local interrupter (CLINT) and does not include any chip specific register
 * extensions then add the path below to the assembler's include path:
 * FreeRTOS\Source\portable\GCC\RISC-V\chip_specific_extensions\RISCV_MTIME_CLINT_no_extensions
 *
 */

/*
 * This freertos_risc_v_chip_specific_extensions.h is for use with Andes V5 core
 * devices, developed and tested using the V5 platforms.
 */

#ifndef __FREERTOS_RISC_V_EXTENSIONS_H__
#define __FREERTOS_RISC_V_EXTENSIONS_H__

#if __riscv_flen == 64
    #define portFPWORD_SIZE 8
    #define fpstore_x fsd
    #define fpload_x fld
#elif __riscv_flen == 32
    #define portFPWORD_SIZE 4
    #define fpstore_x fsw
    #define fpload_x flw
#else
    #define portFPWORD_SIZE 0
#endif

#include "FreeRTOSConfig.h"

#define portasmHAS_MTIME                1

#ifdef configUSE_CLIC
    #define portasmHAS_CLIC             1
#else
    #define portasmHAS_CLIC             0
#endif

#if( configHSP_ENABLE == 1 )
    #define portasmHAS_HSP              1
#else
    #define portasmHAS_HSP              0
#endif

/* Stack's offset in TCB. Unit:byte */
#define StackOffset_TCB                 ( 12 * portWORD_SIZE ) /* The offset of pxCurrentTCB->pxStack in tskTaskControlBlock structure */
#define EndStackOffset_TCB              ( 13 * portWORD_SIZE + configMAX_TASK_NAME_LEN ) /* The offset of pxCurrentTCB->pxEndOfStack in tskTaskControlBlock structure */

/* Constants to define the additional registers. */
#define mxstatus                        0x7c4
#define ucode                           0x801

/* Additional FPU registers to save and restore (fcsr + 32 FPUs) */
#ifdef __riscv_flen
    #define portasmFPU_CONTEXT_SIZE     ( 1 + ( ( 32 * portFPWORD_SIZE ) / portWORD_SIZE ) )
#else
    #define portasmFPU_CONTEXT_SIZE     0
#endif

/* One additional registers to save and restore, as per the #defines above. */
#define portasmADDITIONAL_CONTEXT_SIZE  ( 2 + portasmFPU_CONTEXT_SIZE )

/* Save additional registers found on the V5 core. */
.macro portasmSAVE_ADDITIONAL_REGISTERS
    addi sp, sp, -(portasmADDITIONAL_CONTEXT_SIZE * portWORD_SIZE) /* Make room for the additional registers. */
    csrr t0, mxstatus
    store_x t0, 1 * portWORD_SIZE( sp )

    #ifdef __riscv_dsp
        csrr t0, ucode
        store_x t0, 2 * portWORD_SIZE( sp )
    #endif

    #ifdef __riscv_flen
        frcsr t0
        fpstore_x f0, ( 3 * portWORD_SIZE + 0 * portFPWORD_SIZE )( sp )
        fpstore_x f1, ( 3 * portWORD_SIZE + 1 * portFPWORD_SIZE )( sp )
        fpstore_x f2, ( 3 * portWORD_SIZE + 2 * portFPWORD_SIZE )( sp )
        fpstore_x f3, ( 3 * portWORD_SIZE + 3 * portFPWORD_SIZE )( sp )
        fpstore_x f4, ( 3 * portWORD_SIZE + 4 * portFPWORD_SIZE )( sp )
        fpstore_x f5, ( 3 * portWORD_SIZE + 5 * portFPWORD_SIZE )( sp )
        fpstore_x f6, ( 3 * portWORD_SIZE + 6 * portFPWORD_SIZE )( sp )
        fpstore_x f7, ( 3 * portWORD_SIZE + 7 * portFPWORD_SIZE )( sp )
        fpstore_x f8, ( 3 * portWORD_SIZE + 8 * portFPWORD_SIZE )( sp )
        fpstore_x f9, ( 3 * portWORD_SIZE + 9 * portFPWORD_SIZE )( sp )
        fpstore_x f10, ( 3 * portWORD_SIZE + 10 * portFPWORD_SIZE )( sp )
        fpstore_x f11, ( 3 * portWORD_SIZE + 11 * portFPWORD_SIZE )( sp )
        fpstore_x f12, ( 3 * portWORD_SIZE + 12 * portFPWORD_SIZE )( sp )
        fpstore_x f13, ( 3 * portWORD_SIZE + 13 * portFPWORD_SIZE )( sp )
        fpstore_x f14, ( 3 * portWORD_SIZE + 14 * portFPWORD_SIZE )( sp )
        fpstore_x f15, ( 3 * portWORD_SIZE + 15 * portFPWORD_SIZE )( sp )
        fpstore_x f16, ( 3 * portWORD_SIZE + 16 * portFPWORD_SIZE )( sp )
        fpstore_x f17, ( 3 * portWORD_SIZE + 17 * portFPWORD_SIZE )( sp )
        fpstore_x f18, ( 3 * portWORD_SIZE + 18 * portFPWORD_SIZE )( sp )
        fpstore_x f19, ( 3 * portWORD_SIZE + 19 * portFPWORD_SIZE )( sp )
        fpstore_x f20, ( 3 * portWORD_SIZE + 20 * portFPWORD_SIZE )( sp )
        fpstore_x f21, ( 3 * portWORD_SIZE + 21 * portFPWORD_SIZE )( sp )
        fpstore_x f22, ( 3 * portWORD_SIZE + 22 * portFPWORD_SIZE )( sp )
        fpstore_x f23, ( 3 * portWORD_SIZE + 23 * portFPWORD_SIZE )( sp )
        fpstore_x f24, ( 3 * portWORD_SIZE + 24 * portFPWORD_SIZE )( sp )
        fpstore_x f25, ( 3 * portWORD_SIZE + 25 * portFPWORD_SIZE )( sp )
        fpstore_x f26, ( 3 * portWORD_SIZE + 26 * portFPWORD_SIZE )( sp )
        fpstore_x f27, ( 3 * portWORD_SIZE + 27 * portFPWORD_SIZE )( sp )
        fpstore_x f28, ( 3 * portWORD_SIZE + 28 * portFPWORD_SIZE )( sp )
        fpstore_x f29, ( 3 * portWORD_SIZE + 29 * portFPWORD_SIZE )( sp )
        fpstore_x f30, ( 3 * portWORD_SIZE + 30 * portFPWORD_SIZE )( sp )
        fpstore_x f31, ( 3 * portWORD_SIZE + 31 * portFPWORD_SIZE )( sp )
        sw t0, ( 3 * portWORD_SIZE + 32 * portFPWORD_SIZE )( sp )
    #endif

    .endm

/* Restore the additional registers found on the V5 core. */
.macro portasmRESTORE_ADDITIONAL_REGISTERS
    load_x t0, 1 * portWORD_SIZE( sp )                      /* Load additional registers into accessible temporary registers. */
    csrw mxstatus, t0

    #ifdef __riscv_dsp
        load_x t0, 2 * portWORD_SIZE( sp )
        csrw ucode, t0
    #endif

    #ifdef __riscv_flen
        lw t0, ( 3 * portWORD_SIZE + 32 * portFPWORD_SIZE )( sp )
        fpload_x f0, ( 3 * portWORD_SIZE + 0 * portFPWORD_SIZE )( sp )
        fpload_x f1, ( 3 * portWORD_SIZE + 1 * portFPWORD_SIZE )( sp )
        fpload_x f2, ( 3 * portWORD_SIZE + 2 * portFPWORD_SIZE )( sp )
        fpload_x f3, ( 3 * portWORD_SIZE + 3 * portFPWORD_SIZE )( sp )
        fpload_x f4, ( 3 * portWORD_SIZE + 4 * portFPWORD_SIZE )( sp )
        fpload_x f5, ( 3 * portWORD_SIZE + 5 * portFPWORD_SIZE )( sp )
        fpload_x f6, ( 3 * portWORD_SIZE + 6 * portFPWORD_SIZE )( sp )
        fpload_x f7, ( 3 * portWORD_SIZE + 7 * portFPWORD_SIZE )( sp )
        fpload_x f8, ( 3 * portWORD_SIZE + 8 * portFPWORD_SIZE )( sp )
        fpload_x f9, ( 3 * portWORD_SIZE + 9 * portFPWORD_SIZE )( sp )
        fpload_x f10, ( 3 * portWORD_SIZE + 10 * portFPWORD_SIZE )( sp )
        fpload_x f11, ( 3 * portWORD_SIZE + 11 * portFPWORD_SIZE )( sp )
        fpload_x f12, ( 3 * portWORD_SIZE + 12 * portFPWORD_SIZE )( sp )
        fpload_x f13, ( 3 * portWORD_SIZE + 13 * portFPWORD_SIZE )( sp )
        fpload_x f14, ( 3 * portWORD_SIZE + 14 * portFPWORD_SIZE )( sp )
        fpload_x f15, ( 3 * portWORD_SIZE + 15 * portFPWORD_SIZE )( sp )
        fpload_x f16, ( 3 * portWORD_SIZE + 16 * portFPWORD_SIZE )( sp )
        fpload_x f17, ( 3 * portWORD_SIZE + 17 * portFPWORD_SIZE )( sp )
        fpload_x f18, ( 3 * portWORD_SIZE + 18 * portFPWORD_SIZE )( sp )
        fpload_x f19, ( 3 * portWORD_SIZE + 19 * portFPWORD_SIZE )( sp )
        fpload_x f20, ( 3 * portWORD_SIZE + 20 * portFPWORD_SIZE )( sp )
        fpload_x f21, ( 3 * portWORD_SIZE + 21 * portFPWORD_SIZE )( sp )
        fpload_x f22, ( 3 * portWORD_SIZE + 22 * portFPWORD_SIZE )( sp )
        fpload_x f23, ( 3 * portWORD_SIZE + 23 * portFPWORD_SIZE )( sp )
        fpload_x f24, ( 3 * portWORD_SIZE + 24 * portFPWORD_SIZE )( sp )
        fpload_x f25, ( 3 * portWORD_SIZE + 25 * portFPWORD_SIZE )( sp )
        fpload_x f26, ( 3 * portWORD_SIZE + 26 * portFPWORD_SIZE )( sp )
        fpload_x f27, ( 3 * portWORD_SIZE + 27 * portFPWORD_SIZE )( sp )
        fpload_x f28, ( 3 * portWORD_SIZE + 28 * portFPWORD_SIZE )( sp )
        fpload_x f29, ( 3 * portWORD_SIZE + 29 * portFPWORD_SIZE )( sp )
        fpload_x f30, ( 3 * portWORD_SIZE + 30 * portFPWORD_SIZE )( sp )
        fpload_x f31, ( 3 * portWORD_SIZE + 31 * portFPWORD_SIZE )( sp )
        fscsr t0
    #endif

    addi sp, sp, (portasmADDITIONAL_CONTEXT_SIZE * portWORD_SIZE )/* Remove space added for additional registers. */
    .endm

/* Set the HSP SP bound and base registers for ISR stack */
.macro portasmSWITCH_TO_ISRSTACK_HSP
    load_x t1, xISRStackTop

    #ifdef configISR_STACK_SIZE_WORDS
        addi t0, t1, -( ( configISR_STACK_SIZE_WORDS & ~( portBYTE_ALIGNMENT - 1 ) ) * portWORD_SIZE )
    #else
        la t0, _end
    #endif

    csrw msp_bound, t0                                      /* Set the SP bound register (low address) */
    csrw msp_base, t1                                       /* Set the SP base register (high address) */
    .endm

/* Set the HSP SP bound and base registers for thread stack */
.macro portasmSWITCH_TO_THREADSTACK_HSP
    load_x t1, pxCurrentTCB
    load_x t0, StackOffset_TCB(t1)
    load_x t1, EndStackOffset_TCB(t1)
    csrw msp_bound, t0                                      /* Set the SP bound register (low address) */
    csrw msp_base, t1                                       /* Set the SP base register (high address) */
    .endm

#endif /* __FREERTOS_RISC_V_EXTENSIONS_H__ */
